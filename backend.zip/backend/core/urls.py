"""
URL configuration for core app.
"""
from django.urls import path

app_name = 'core'

urlpatterns = [
    # Core endpoints can be added here if needed
]
